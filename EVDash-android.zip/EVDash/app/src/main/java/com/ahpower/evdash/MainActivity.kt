package com.ahpower.evdash

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.app.AlertDialog
import android.bluetooth.*
import android.bluetooth.le.*
import android.content.Context
import android.content.pm.PackageManager
import android.graphics.Typeface
import android.os.*
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.widget.*
import java.nio.ByteBuffer
import java.util.UUID
import kotlin.math.PI
import kotlin.math.abs

@SuppressLint("MissingPermission")
class MainActivity : Activity() {
    private fun u(s: String) = UUID.fromString(s)
    private fun s16(n: String) = u("0000$n-0000-1000-8000-00805f9b34fb")
    private val NUS = "6e400001-b5a3-f393-e0a9-e50e24dcca9e"
    // type -> service, write, notify
    private val prof: Map<String, Triple<UUID, UUID, UUID>> by lazy { mapOf(
        "VESC" to Triple(u(NUS), u("6e400002-b5a3-f393-e0a9-e50e24dcca9e"), u("6e400003-b5a3-f393-e0a9-e50e24dcca9e")),
        "Fardriver" to Triple(s16("ffe0"), s16("ffec"), s16("ffec")),
        "Daly BMS" to Triple(s16("fff0"), s16("fff2"), s16("fff1")),
        "JK BMS" to Triple(s16("ffe0"), s16("ffe1"), s16("ffe1")),
        "ANT BMS" to Triple(s16("ff00"), s16("ff02"), s16("ff01")),
        "Votol SPP" to Triple(s16("1101"), s16("1101"), s16("1101"))) }

    private val h = Handler(Looper.getMainLooper())
    private lateinit var spin: Spinner; private lateinit var main: TextView; private lateinit var raw: TextView
    private lateinit var status: TextView; private lateinit var btn: Button
    private lateinit var pp: EditText; private lateinit var gr: EditText; private lateinit var wd: EditText
    private var gatt: BluetoothGatt? = null; private var tx: BluetoothGattCharacteristic? = null
    private var sock: BluetoothSocket? = null
    private val buf = ArrayList<Int>(); private var type = "VESC"; private var tries = 0; private var manual = false
    private var lastDev: BluetoothDevice? = null; private var poll: Runnable? = null

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val d = resources.displayMetrics.density
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding((16 * d).toInt(), (24 * d).toInt(), (16 * d).toInt(), 16 * d.toInt()) }
        spin = Spinner(this).apply { adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, prof.keys.toList()) }
        btn = Button(this).apply { text = "اتصال"; setOnClickListener { if (gatt != null || sock != null) disconnect() else scan() } }
        status = TextView(this).apply { text = "غير متصل" }
        main = TextView(this).apply { textSize = 22f; typeface = Typeface.MONOSPACE; text = "--" }
        pp = num("15"); gr = num("1"); wd = num("10")
        raw = TextView(this).apply { textSize = 11f; typeface = Typeface.MONOSPACE }
        root.addView(spin); root.addView(btn); root.addView(status)
        root.addView(TextView(this).apply { text = "Pole pairs / نسبة القير / قطر الإطار (إنج)" })
        root.addView(LinearLayout(this).apply { addView(pp, LinearLayout.LayoutParams(0, -2, 1f)); addView(gr, LinearLayout.LayoutParams(0, -2, 1f)); addView(wd, LinearLayout.LayoutParams(0, -2, 1f)) })
        root.addView(main)
        root.addView(ScrollView(this).apply { addView(raw) })
        setContentView(root)
        window.decorView.layoutDirection = View.LAYOUT_DIRECTION_RTL
    }
    private fun num(v: String) = EditText(this).apply { setText(v); inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL }

    private fun perms(): Boolean {
        val need = if (Build.VERSION.SDK_INT >= 31) arrayOf(Manifest.permission.BLUETOOTH_SCAN, Manifest.permission.BLUETOOTH_CONNECT)
                   else arrayOf(Manifest.permission.ACCESS_FINE_LOCATION)
        val miss = need.filter { checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED }
        if (miss.isNotEmpty()) { requestPermissions(miss.toTypedArray(), 1); return false }
        return true
    }

    private fun scan() {
        if (!perms()) return
        type = spin.selectedItem as String; manual = false; tries = 0; buf.clear()
        val ad = (getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager).adapter
        if (!ad.isEnabled) { status.text = "شغّل البلوتوث"; return }
        if (type == "Votol SPP") {
            val list = ad.bondedDevices.toList()
            pick(list) { spp(it) }; return
        }
        val found = LinkedHashMap<String, BluetoothDevice>()
        val cb = object : ScanCallback() {
            override fun onScanResult(t: Int, r: ScanResult) { found[r.device.address] = r.device }
        }
        status.text = "جاري البحث..."
        ad.bluetoothLeScanner.startScan(cb)
        h.postDelayed({ ad.bluetoothLeScanner.stopScan(cb); pick(found.values.toList()) { connect(it) } }, 6000)
    }
    private fun pick(l: List<BluetoothDevice>, go: (BluetoothDevice) -> Unit) {
        if (l.isEmpty()) { status.text = "ما لقيت أجهزة"; return }
        val names = l.map { "${it.name ?: "؟"}  ${it.address}" }.toTypedArray()
        AlertDialog.Builder(this).setTitle("اختر الجهاز").setItems(names) { _, i -> go(l[i]) }.show()
    }

    private fun connect(dv: BluetoothDevice) {
        lastDev = dv; status.text = "جاري الاتصال..."
        gatt = dv.connectGatt(this, false, cb, BluetoothDevice.TRANSPORT_LE)
        btn.text = "قطع الاتصال"
    }
    private val cb = object : BluetoothGattCallback() {
        override fun onConnectionStateChange(g: BluetoothGatt, st: Int, ns: Int) {
            if (ns == BluetoothProfile.STATE_CONNECTED) g.discoverServices()
            else if (ns == BluetoothProfile.STATE_DISCONNECTED) {
                g.close(); poll?.let { h.removeCallbacks(it) }
                h.post {
                    if (!manual && tries < 3 && lastDev != null) { tries++; status.text = "إعادة المحاولة $tries/3"; h.postDelayed({ connect(lastDev!!) }, tries * 2000L) }
                    else { gatt = null; btn.text = "اتصال"; status.text = "انقطع الاتصال" }
                }
            }
        }
        override fun onServicesDiscovered(g: BluetoothGatt, st: Int) {
            val p = prof[type]!!; val svc = g.getService(p.first)
            if (svc == null) { h.post { status.text = "الخدمة غير موجودة بهذا الجهاز" }; return }
            tx = svc.getCharacteristic(p.second)
            val rx = svc.getCharacteristic(p.third)
            g.setCharacteristicNotification(rx, true)
            rx.getDescriptor(s16("2902"))?.let { it.value = BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE; g.writeDescriptor(it) }
        }
        override fun onDescriptorWrite(g: BluetoothGatt, d: BluetoothGattDescriptor, st: Int) {
            tries = 0; h.post { status.text = "متصل" ; startPoll() }
        }
        @Deprecated("old signature")
        override fun onCharacteristicChanged(g: BluetoothGatt, c: BluetoothGattCharacteristic) { feed(c.value) }
    }

    private fun startPoll() {
        val pk = pollPacket() ?: return
        poll = object : Runnable { override fun run() {
            tx?.let { it.writeType = BluetoothGattCharacteristic.WRITE_TYPE_NO_RESPONSE; it.value = pk; gatt?.writeCharacteristic(it) }
            h.postDelayed(this, 300) } }
        h.post(poll!!)
    }
    private fun crcCcitt(b: ByteArray): Int { var c = 0; for (x in b) { c = c xor ((x.toInt() and 255) shl 8); repeat(8) { c = if (c and 0x8000 != 0) (c shl 1) xor 0x1021 else c shl 1; c = c and 0xffff } }; return c }
    private fun crcA001(b: ByteArray): Int { var c = 0xffff; for (x in b) { c = c xor (x.toInt() and 255); repeat(8) { c = if (c and 1 != 0) (c shr 1) xor 0xa001 else c shr 1 } }; return c }
    private fun pollPacket(): ByteArray? = when (type) {
        "VESC" -> { val c = crcCcitt(byteArrayOf(4)); byteArrayOf(2, 1, 4, (c shr 8).toByte(), c.toByte(), 3) }
        "Fardriver" -> { val f = byteArrayOf(0xAA.toByte(), 4, 1, 0, 0); val c = crcA001(f); f + byteArrayOf(c.toByte(), (c shr 8).toByte()) }
        else -> null
    }

    // ---- Votol SPP (RFCOMM): offsets from the analysis doc, unverified ----
    private fun spp(dv: BluetoothDevice) {
        btn.text = "قطع الاتصال"; status.text = "جاري الاتصال (SPP)..."
        Thread {
            try {
                val s = dv.createRfcommSocketToServiceRecord(s16("1101")); s.connect(); sock = s
                h.post { status.text = "متصل (SPP)" }
                val i = s.inputStream; val a = ByteArray(256)
                while (true) { val n = i.read(a); if (n < 0) break; feed(a.copyOf(n)) }
            } catch (e: Exception) { h.post { status.text = "خطأ: ${e.message}" } }
            h.post { sock = null; btn.text = "اتصال" }
        }.start()
    }

    private fun disconnect() {
        manual = true; poll?.let { h.removeCallbacks(it) }
        gatt?.disconnect(); try { sock?.close() } catch (_: Exception) {}
        if (gatt == null) { sock = null; btn.text = "اتصال" }
        status.text = "تم قطع الاتصال"
    }

    private fun feed(a: ByteArray) {
        a.forEach { buf.add(it.toInt() and 255) }
        if (buf.size > 2000) repeat(buf.size - 500) { buf.removeAt(0) }
        val hx = a.joinToString(" ") { "%02x".format(it) }
        h.post { raw.text = (hx + "\n" + raw.text).take(3000) }
        when (type) { "VESC" -> vesc(); "Daly BMS" -> daly(); "Votol SPP" -> votol() }
    }

    private fun vesc() {
        while (buf.size > 5) {
            val s = buf.indexOf(2); if (s < 0) { buf.clear(); return }
            repeat(s) { buf.removeAt(0) }
            val len = buf[1]; val tot = len + 5; if (buf.size < tot) return
            val fr = buf.subList(0, tot).map { it.toByte() }.toByteArray(); repeat(tot) { buf.removeAt(0) }
            if (fr[tot - 1].toInt() != 3) continue
            val p = ByteBuffer.wrap(fr, 2, len)
            if (fr[2].toInt() != 4 || len < 30) continue
            val d = ByteBuffer.wrap(fr.copyOfRange(2, 2 + len))
            val tMos = d.getShort(1) / 10.0; val tMot = d.getShort(3) / 10.0
            val ci = d.getInt(9) / 100.0; val rpm = d.getInt(25); val vin = d.getShort(29) / 10.0
            val ppv = pp.text.toString().toDoubleOrNull() ?: 1.0; val g = gr.text.toString().toDoubleOrNull() ?: 1.0
            val dm = (wd.text.toString().toDoubleOrNull() ?: 10.0) * 0.0254
            val spd = abs(rpm) / ppv / g * PI * dm * 60 / 1000
            show("%.0f km/h\n%.1f V   %.1f A\n%.0f W\nRPM %d\nMotor %.0f°  MOS %.0f°".format(spd, vin, ci, vin * ci, rpm, tMot, tMos))
        }
    }
    private fun daly() {
        var s = -1; for (i in 0 until buf.size - 1) if (buf[i] == 0xAA && buf[i + 1] == 0x55) { s = i; break }
        if (s < 0) { if (buf.size > 300) buf.clear(); return }
        repeat(s) { buf.removeAt(0) }
        if (buf.size < 140) return
        val f = buf.subList(0, 140).toList(); repeat(140) { buf.removeAt(0) }
        fun u16(o: Int) = (f[o] shl 8) or f[o + 1]
        val cells = (0 until 32).map { u16(6 + it * 2) * 0.001 }.filter { it > 0.5 }
        show("%.1f V   %.1f A\nSOC %d%%\nTemp %d°\n\n".format(u16(4) * 0.1, u16(70) * 0.1, f[74], f[91]) +
            cells.mapIndexed { i, c -> "%02d: %.3f".format(i + 1, c) }.chunked(2).joinToString("\n") { it.joinToString("    ") })
    }
    private fun votol() {
        if (buf.size < 21) return
        val f = buf.takeLast(21); buf.clear()
        val rpm = (f[5] or (f[6] shl 8)) / 10.0; val spd = (f[7] or (f[8] shl 8)).toShort() / 10.0
        show("%.1f km/h\nRPM %.0f\nGear %d  brake=%b reverse=%b".format(spd, rpm, f[20] and 3, f[20] and 4 != 0, f[20] and 8 != 0))
    }
    private fun show(t: String) = h.post { main.text = t }
}
