package com.ahpower.evdash

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.app.AlertDialog
import android.bluetooth.*
import android.bluetooth.le.*
import android.content.Context
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.*
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.widget.*
import java.nio.ByteBuffer
import java.util.UUID
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.max

fun s16(n: String): UUID = UUID.fromString("0000$n-0000-1000-8000-00805f9b34fb")
fun u(s: String): UUID = UUID.fromString(s)
// kind -> service, write, notify
val PROF: Map<String, Triple<UUID, UUID, UUID>> = mapOf(
    "VESC" to Triple(u("6e400001-b5a3-f393-e0a9-e50e24dcca9e"), u("6e400002-b5a3-f393-e0a9-e50e24dcca9e"), u("6e400003-b5a3-f393-e0a9-e50e24dcca9e")),
    "Fardriver" to Triple(s16("ffe0"), s16("ffec"), s16("ffec")),
    "Daly" to Triple(s16("fff0"), s16("fff2"), s16("fff1")),
    "JK" to Triple(s16("ffe0"), s16("ffe1"), s16("ffe1")),
    "ANT" to Triple(s16("ff00"), s16("ff02"), s16("ff01")),
    "Votol SPP" to Triple(s16("1101"), s16("1101"), s16("1101")))
val CTRL = listOf("Fardriver", "VESC", "Votol SPP")
val BMSL = listOf("JK", "Daly", "ANT")

object D {
    @Volatile var spd = 0.0; @Volatile var v = 0.0; @Volatile var a = 0.0; @Volatile var rpm = 0.0
    @Volatile var soc = -1.0; @Volatile var tm = Double.NaN; @Volatile var tmos = Double.NaN
    @Volatile var cells: List<Double> = emptyList(); val minCell = DoubleArray(40) { 9.0 }
    @Volatile var trip = 0.0; @Volatile var top = 0.0; @Volatile var kwh = 0.0
    @Volatile var t0 = 0L; @Volatile var last = 0L; @Volatile var cOk = false; @Volatile var bOk = false
    fun reset() { trip = 0.0; top = 0.0; kwh = 0.0; t0 = 0L; last = 0L; minCell.fill(9.0) }
}

@SuppressLint("MissingPermission")
class Link(val ctx: Context, val kind: String, val auto: () -> Boolean, val status: (String) -> Unit, val onUp: (Boolean) -> Unit, val feed: (Link, ByteArray) -> Unit) {
    val h = Handler(Looper.getMainLooper()); val buf = ArrayList<Int>()
    var gatt: BluetoothGatt? = null; var tx: BluetoothGattCharacteristic? = null; var sock: BluetoothSocket? = null
    var dev: BluetoothDevice? = null; var tries = 0; var manual = false; var poll: Runnable? = null
    val active get() = gatt != null || sock != null
    fun open(d: BluetoothDevice) { dev = d; manual = false; tries = 0; go() }
    private fun go() {
        status("جاري الاتصال...")
        if (kind == "Votol SPP") spp() else gatt = dev!!.connectGatt(ctx, false, cb, BluetoothDevice.TRANSPORT_LE)
    }
    fun close() { manual = true; poll?.let { h.removeCallbacks(it) }; gatt?.disconnect(); try { sock?.close() } catch (_: Exception) {}; if (gatt == null) { sock = null; onUp(false) } }
    private val cb = object : BluetoothGattCallback() {
        override fun onConnectionStateChange(g: BluetoothGatt, st: Int, ns: Int) {
            if (ns == BluetoothProfile.STATE_CONNECTED) { g.requestConnectionPriority(BluetoothGatt.CONNECTION_PRIORITY_HIGH); g.discoverServices() }
            else if (ns == BluetoothProfile.STATE_DISCONNECTED) {
                g.close(); poll?.let { h.removeCallbacks(it) }; gatt = null
                h.post { onUp(false)
                    if (!manual && auto() && tries < 8) { tries++; status("إعادة المحاولة $tries"); gatt = dev!!.connectGatt(ctx, false, this, BluetoothDevice.TRANSPORT_LE) }
                    else status("غير متصل") }
            }
        }
        override fun onServicesDiscovered(g: BluetoothGatt, st: Int) {
            val p = PROF[kind]!!; val svc = g.getService(p.first)
            var w = svc?.getCharacteristic(p.second); var r = svc?.getCharacteristic(p.third)
            if (w == null || r == null) {
                val all = g.services.filter { !it.uuid.toString().startsWith("00001800") && !it.uuid.toString().startsWith("00001801") }.flatMap { it.characteristics }
                r = all.firstOrNull { it.properties and (BluetoothGattCharacteristic.PROPERTY_NOTIFY or BluetoothGattCharacteristic.PROPERTY_INDICATE) != 0 }
                w = all.firstOrNull { it.properties and (BluetoothGattCharacteristic.PROPERTY_WRITE or BluetoothGattCharacteristic.PROPERTY_WRITE_NO_RESPONSE) != 0 }
            }
            tx = w
            if (r == null) { h.post { status("لا توجد قناة بيانات") }; return }
            g.setCharacteristicNotification(r, true)
            val d = r.getDescriptor(s16("2902"))
            if (d == null) { ready(); return }
            d.value = if (r.properties and BluetoothGattCharacteristic.PROPERTY_NOTIFY != 0) BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE else BluetoothGattDescriptor.ENABLE_INDICATION_VALUE
            if (!g.writeDescriptor(d)) ready()
        }
        override fun onDescriptorWrite(g: BluetoothGatt, d: BluetoothGattDescriptor, st: Int) { ready() }
        @Deprecated("old") override fun onCharacteristicChanged(g: BluetoothGatt, c: BluetoothGattCharacteristic) { feed(this@Link, c.value) }
    }
    private fun ready() { tries = 0; h.post { status("متصل"); onUp(true); startPoll() } }
    private fun crcC(b: ByteArray): Int { var c = 0; for (x in b) { c = c xor ((x.toInt() and 255) shl 8); repeat(8) { c = if (c and 0x8000 != 0) (c shl 1) xor 0x1021 else c shl 1; c = c and 0xffff } }; return c }
    private fun crcA(b: ByteArray): Int { var c = 0xffff; for (x in b) { c = c xor (x.toInt() and 255); repeat(8) { c = if (c and 1 != 0) (c shr 1) xor 0xa001 else c shr 1 } }; return c }
    private fun pk(): ByteArray? = when (kind) {
        "VESC" -> { val c = crcC(byteArrayOf(4)); byteArrayOf(2, 1, 4, (c shr 8).toByte(), c.toByte(), 3) }
        "Fardriver" -> null
        else -> null }
    private fun startPoll() {
        val p = pk() ?: return
        poll = object : Runnable { override fun run() {
            tx?.let { it.writeType = BluetoothGattCharacteristic.WRITE_TYPE_NO_RESPONSE; it.value = p; gatt?.writeCharacteristic(it) }
            h.postDelayed(this, 250) } }
        h.post(poll!!)
    }
    private fun spp() {
        Thread {
            try {
                val s = dev!!.createRfcommSocketToServiceRecord(s16("1101")); s.connect(); sock = s
                h.post { status("متصل"); onUp(true) }
                val i = s.inputStream; val a = ByteArray(256)
                while (true) { val n = i.read(a); if (n < 0) break; feed(this, a.copyOf(n)) }
            } catch (e: Exception) { h.post { status("خطأ: ${e.message}") } }
            sock = null; h.post { onUp(false) }
        }.start()
    }
}

@SuppressLint("MissingPermission")
class MainActivity : Activity() {
    private val h = Handler(Looper.getMainLooper())
    private lateinit var sp: SharedPreferences
    private val BG = Color.parseColor("#0F1923"); private val PN = Color.parseColor("#192634"); private val AC = Color.parseColor("#FFB547")
    private val CY = Color.parseColor("#4CC9F0"); private val TX = Color.parseColor("#E8EEF4"); private val MU = Color.parseColor("#8396AB")
    private lateinit var frame: FrameLayout; private lateinit var nav: LinearLayout
    private val pages = ArrayList<View>(); private val ups = ArrayList<() -> Unit>()
    private var ctrl: Link? = null; private var bms: Link? = null
    private var rawLog = ""; private lateinit var stC: TextView; private lateinit var stB: TextView; private lateinit var rawTv: TextView

    private fun dp(x: Int) = (x * resources.displayMetrics.density).toInt()
    private fun bg(c: Int, r: Int = 14) = GradientDrawable().apply { setColor(c); cornerRadius = dp(r).toFloat() }
    private fun tv(t: String, sz: Float = 14f, c: Int = TX, b: Boolean = false) = TextView(this).apply { text = t; textSize = sz; setTextColor(c); if (b) typeface = Typeface.DEFAULT_BOLD }
    private fun col() = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(14), dp(14), dp(14), dp(14)) }
    private fun card(label: String, unit: String, upd: () -> String): View {
        val v = tv("--", 26f, TX, true); val l = tv(label, 12f, MU)
        val c = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; background = bg(PN); setPadding(dp(12), dp(10), dp(12), dp(10)); addView(l); addView(LinearLayout(context).apply { addView(v); addView(tv(" $unit", 13f, MU)) }) }
        ups.add { v.text = upd() }; return c
    }
    private fun row(vararg v: View) = LinearLayout(this).apply { weightSum = v.size.toFloat(); v.forEach { addView(it, LinearLayout.LayoutParams(0, -2, 1f).apply { setMargins(dp(4), dp(4), dp(4), dp(4)) }) } }
    private fun btn(t: String, f: () -> Unit) = Button(this).apply { text = t; setTextColor(Color.BLACK); background = bg(AC, 12); setOnClickListener { f() } }
    private fun mph() = sp.getBoolean("mph", false); private fun fh() = sp.getBoolean("f", false)
    private fun spdU(k: Double) = if (mph()) k * 0.621371 else k
    private fun tmpU(c: Double) = if (c.isNaN()) "--" else "%.0f".format(if (fh()) c * 1.8 + 32 else c)

    override fun onCreate(b: Bundle?) {
        super.onCreate(b); sp = getSharedPreferences("ev", MODE_PRIVATE)
        window.statusBarColor = BG; window.navigationBarColor = PN
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(BG) }
        frame = FrameLayout(this); nav = LinearLayout(this).apply { setBackgroundColor(PN) }
        root.addView(frame, LinearLayout.LayoutParams(-1, 0, 1f)); root.addView(nav, LinearLayout.LayoutParams(-1, dp(56)))
        setContentView(root); window.decorView.layoutDirection = View.LAYOUT_DIRECTION_RTL
        buildRide(); buildBattery(); buildTrip(); buildSettings(); buildProfile()
        listOf("القيادة", "البطارية", "الرحلة", "الإعدادات", "البروفايل").forEachIndexed { i, n ->
            nav.addView(Button(this).apply { text = n; textSize = 12f; setTextColor(TX); setBackgroundColor(Color.TRANSPARENT); setOnClickListener { show(i) } }, LinearLayout.LayoutParams(0, -1, 1f)) }
        show(0)
        h.post(object : Runnable { override fun run() { ups.forEach { it() }; h.postDelayed(this, 250) } })
        if (perms()) autoStart()
    }
    private fun show(i: Int) { frame.removeAllViews(); frame.addView(pages[i]); for (k in 0 until nav.childCount) (nav.getChildAt(k) as Button).setTextColor(if (k == i) AC else TX) }

    private fun buildRide() {
        val c = col(); val big = tv("0", 110f, TX, true).apply { gravity = Gravity.CENTER }
        val unit = tv("km/h", 16f, MU).apply { gravity = Gravity.CENTER }
        val bar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply { max = 100; progressDrawable.setTint(AC) }
        c.addView(big); c.addView(unit); c.addView(bar)
        c.addView(row(card("الفولتية", "V") { "%.1f".format(D.v) }, card("التيار", "A") { "%.1f".format(D.a) }))
        c.addView(row(card("القدرة", "W") { "%.0f".format(D.v * D.a) }, card("RPM", "") { "%.0f".format(D.rpm) }))
        c.addView(row(card("حرارة المحرك", if (fh()) "°F" else "°C") { tmpU(D.tm) }, card("حرارة MOSFET", if (fh()) "°F" else "°C") { tmpU(D.tmos) }))
        ups.add { big.text = "%.0f".format(spdU(D.spd)); unit.text = if (mph()) "mph" else "km/h"; bar.progress = (abs(D.v * D.a) / 50).toInt().coerceIn(0, 100) }
        pages.add(ScrollView(this).apply { addView(c) })
    }
    private fun socNow(): Double {
        if (D.soc >= 0) return D.soc
        val lo = (sp.getString("vmin", "60") ?: "60").toDoubleOrNull() ?: 60.0; val hi = (sp.getString("vmax", "84") ?: "84").toDoubleOrNull() ?: 84.0
        return if (D.v <= 0 || hi <= lo) -1.0 else ((D.v - lo) / (hi - lo) * 100).coerceIn(0.0, 100.0)
    }
    private fun buildBattery() {
        val c = col(); val soc = tv("--", 72f, AC, true).apply { gravity = Gravity.CENTER }
        val bar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply { max = 100; progressDrawable.setTint(CY) }
        c.addView(soc); c.addView(bar)
        c.addView(row(card("الفولتية", "V") { "%.1f".format(D.v) }, card("التيار", "A") { "%.1f".format(D.a) }))
        c.addView(row(card("أعلى خلية", "V") { if (D.cells.isEmpty()) "--" else "%.3f".format(D.cells.max()) }, card("أقل خلية", "V") { if (D.cells.isEmpty()) "--" else "%.3f".format(D.cells.min()) }))
        c.addView(row(card("فرق الخلايا", "mV") { if (D.cells.isEmpty()) "--" else "%.0f".format((D.cells.max() - D.cells.min()) * 1000) }))
        val grid = GridLayout(this).apply { columnCount = 4 }; c.addView(grid); var n = -1
        ups.add {
            val s = socNow(); soc.text = if (s < 0) "--%" else "%.0f%%".format(s); bar.progress = max(0.0, s).toInt()
            val cl = D.cells
            if (cl.size != n) { n = cl.size; grid.removeAllViews(); cl.indices.forEach { grid.addView(tv("", 12f).apply { background = bg(PN, 8); setPadding(dp(6), dp(6), dp(6), dp(6)); tag = it }, GridLayout.LayoutParams().apply { width = (resources.displayMetrics.widthPixels - dp(60)) / 4; setMargins(dp(3), dp(3), dp(3), dp(3)) }) } }
            for (i in cl.indices) { D.minCell[i] = minOf(D.minCell[i], cl[i]); (grid.getChildAt(i) as? TextView)?.text = "C%02d\n%.3f\nmin %.3f".format(i + 1, cl[i], D.minCell[i]) }
        }
        c.addView(btn("تصفير أقل القيم") { D.minCell.fill(9.0) })
        pages.add(ScrollView(this).apply { addView(c) })
    }
    private fun buildTrip() {
        val c = col()
        c.addView(row(card("المسافة", if (mph()) "mi" else "km") { "%.2f".format(spdU(D.trip)) }, card("الوقت", "") { val s = if (D.t0 == 0L) 0 else (System.currentTimeMillis() - D.t0) / 1000; "%d:%02d".format(s / 60, s % 60) }))
        c.addView(row(card("الاستهلاك", "kWh") { "%.3f".format(D.kwh) }, card("أعلى سرعة", "") { "%.0f".format(spdU(D.top)) }))
        c.addView(row(card("Wh لكل كم", "") { if (D.trip < 0.05) "--" else "%.1f".format(D.kwh * 1000 / D.trip) }))
        c.addView(btn("تصفير الرحلة") { D.reset() })
        pages.add(ScrollView(this).apply { addView(c) })
    }

    private fun sw(t: String, k: String, def: Boolean) = Switch(this).apply { text = t; setTextColor(TX); isChecked = sp.getBoolean(k, def); setOnCheckedChangeListener { _, v -> sp.edit().putBoolean(k, v).apply() } }
    private fun ed(t: String, k: String, def: String) = LinearLayout(this).apply { addView(tv(t, 13f, MU), LinearLayout.LayoutParams(0, -2, 1f)); addView(EditText(context).apply { setText(sp.getString(k, def)); setTextColor(TX); inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL; addTextChangedListener(object : android.text.TextWatcher { override fun afterTextChanged(s: android.text.Editable?) { sp.edit().putString(k, s.toString()).apply() }; override fun beforeTextChanged(a: CharSequence?, b: Int, c: Int, d: Int) {}; override fun onTextChanged(a: CharSequence?, b: Int, c: Int, d: Int) {} }) }, LinearLayout.LayoutParams(dp(110), -2)) }
    private fun spin(k: String, items: List<String>) = Spinner(this).apply { adapter = ArrayAdapter(context, android.R.layout.simple_spinner_dropdown_item, items); setSelection(items.indexOf(sp.getString(k, items[0])).coerceAtLeast(0))
        onItemSelectedListener = object : AdapterView.OnItemSelectedListener { override fun onItemSelected(p: AdapterView<*>?, v: View?, i: Int, id: Long) { sp.edit().putString(k, items[i]).apply() }; override fun onNothingSelected(p: AdapterView<*>?) {} } }
    private fun buildSettings() {
        val c = col(); stC = tv("الكونترولر: غير متصل", 13f, MU); stB = tv("البطارية: غير متصل", 13f, MU)
        c.addView(tv("نوع الكونترولر", 13f, MU)); c.addView(spin("ctrl", CTRL)); c.addView(btn("اتصال / قطع الكونترولر") { toggle(true) }); c.addView(stC)
        c.addView(tv("نوع الـ BMS", 13f, MU)); c.addView(spin("bms", BMSL)); c.addView(btn("اتصال / قطع البطارية") { toggle(false) }); c.addView(stB)
        c.addView(ed("Pole pairs", "pp", "15")); c.addView(ed("نسبة القير", "gr", "1")); c.addView(ed("قطر الإطار (إنج)", "wd", "10"))
        c.addView(ed("Vmin للبطارية", "vmin", "60")); c.addView(ed("Vmax للبطارية", "vmax", "84"))
        c.addView(sw("إعادة اتصال تلقائي", "auto", true)); c.addView(sw("mph بدل km/h", "mph", false)); c.addView(sw("°F بدل °C", "f", false))
        c.addView(btn("نسيان الأجهزة المحفوظة") { sp.edit().remove("cAddr").remove("bAddr").apply() })
        rawTv = tv("", 10f, MU).apply { typeface = Typeface.MONOSPACE }; c.addView(tv("البيانات الخام", 13f, MU)); c.addView(rawTv)
        ups.add { rawTv.text = rawLog }
        pages.add(ScrollView(this).apply { addView(c) })
    }
    private val KEYS = listOf("ctrl", "bms", "pp", "gr", "wd", "vmin", "vmax", "mph", "f", "auto")
    private fun buildProfile() {
        val c = col(); val msg = tv("", 13f, MU)
        for (n in 1..2) { c.addView(btn("حفظ الإعدادات في بروفايل $n") { sp.edit().putString("p$n", KEYS.joinToString(";") { k -> "$k=${sp.all[k]}" }).apply(); msg.text = "تم الحفظ" })
            c.addView(btn("تحميل بروفايل $n") { val s = sp.getString("p$n", null); if (s == null) msg.text = "ما في بروفايل محفوظ" else { val e = sp.edit(); s.split(";").forEach { kv -> val (k, v) = kv.split("=", limit = 2); e.apply { when (v) { "true" -> putBoolean(k, true); "false" -> putBoolean(k, false); else -> putString(k, v) } } }; e.apply(); msg.text = "تم التحميل. أعد فتح التطبيق لتطبيق كل القيم" } }) }
        c.addView(msg); pages.add(c)
    }

    private fun perms(): Boolean {
        val need = if (Build.VERSION.SDK_INT >= 31) arrayOf(Manifest.permission.BLUETOOTH_SCAN, Manifest.permission.BLUETOOTH_CONNECT) else arrayOf(Manifest.permission.ACCESS_FINE_LOCATION)
        val miss = need.filter { checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED }
        if (miss.isNotEmpty()) { requestPermissions(miss.toTypedArray(), 1); return false }; return true
    }
    override fun onRequestPermissionsResult(r: Int, p: Array<out String>, g: IntArray) { if (g.all { it == PackageManager.PERMISSION_GRANTED }) autoStart() }
    private fun ad() = (getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager).adapter
    private fun autoStart() { for (isC in listOf(true, false)) { val a = sp.getString(if (isC) "cAddr" else "bAddr", null) ?: continue; try { open(isC, ad().getRemoteDevice(a)) } catch (_: Exception) {} } }
    private fun toggle(isC: Boolean) {
        val l = if (isC) ctrl else bms
        if (l != null && l.active) { l.close(); return }
        if (!perms()) return
        val kind = sp.getString(if (isC) "ctrl" else "bms", if (isC) "Fardriver" else "JK")!!
        if (kind == "Votol SPP") { val d = ad().bondedDevices.toList(); pick(d) { sp.edit().putString("cAddr", it.address).apply(); open(true, it) }; return }
        val found = LinkedHashMap<String, BluetoothDevice>()
        val cb = object : ScanCallback() { override fun onScanResult(t: Int, r: ScanResult) { found[r.device.address] = r.device } }
        (if (isC) stC else stB).text = "جاري البحث..."
        ad().bluetoothLeScanner.startScan(cb)
        h.postDelayed({ ad().bluetoothLeScanner.stopScan(cb); pick(found.values.toList()) { sp.edit().putString(if (isC) "cAddr" else "bAddr", it.address).apply(); open(isC, it) } }, 4000)
    }
    private fun pick(l: List<BluetoothDevice>, go: (BluetoothDevice) -> Unit) {
        if (l.isEmpty()) { Toast.makeText(this, "ما لقيت أجهزة", Toast.LENGTH_SHORT).show(); return }
        AlertDialog.Builder(this).setTitle("اختر الجهاز").setItems(l.map { "${it.name ?: "؟"}  ${it.address}" }.toTypedArray()) { _, i -> go(l[i]) }.show()
    }
    private fun open(isC: Boolean, d: BluetoothDevice) {
        val kind = sp.getString(if (isC) "ctrl" else "bms", if (isC) "Fardriver" else "JK")!!
        val l = Link(this, kind, { sp.getBoolean("auto", true) }, { s -> h.post { (if (isC) stC else stB).text = (if (isC) "الكونترولر: " else "البطارية: ") + s } },
            { up -> if (isC) D.cOk = up else D.bOk = up }, { lk, a -> onBytes(lk, a, isC) })
        if (isC) ctrl = l else bms = l; l.open(d)
    }

    private fun onBytes(l: Link, a: ByteArray, isC: Boolean) {
        a.forEach { l.buf.add(it.toInt() and 255) }
        if (l.buf.size > 2000) l.buf.subList(0, l.buf.size - 500).clear()
        if (l.kind == "Fardriver") fard(l.buf) else rawLog = (a.joinToString(" ") { "%02x".format(it) } + "\n" + rawLog).take(1500)
        when (l.kind) { "VESC" -> vesc(l.buf); "Daly" -> daly(l.buf); "Votol SPP" -> votol(l.buf) }
    }
    private val frames = java.util.TreeMap<Int, String>()
    private fun fard(buf: ArrayList<Int>) {
        while (buf.size >= 16) {
            val i = buf.indexOf(0xAA); if (i < 0) { buf.clear(); return }
            if (i > 0) buf.subList(0, i).clear()
            if (buf.size < 16) return
            val f = buf.subList(0, 16).toList(); buf.subList(0, 16).clear()
            frames[f[1]] = f.drop(2).joinToString(" ") { "%02x".format(it) }
        }
        rawLog = frames.entries.joinToString("\n") { "%02x: %s".format(it.key, it.value) }
    }
    private fun integrate() {
        val now = System.currentTimeMillis(); if (D.t0 == 0L) D.t0 = now
        if (D.last != 0L) { val dt = now - D.last; if (dt in 1..2000) { D.trip += D.spd * dt / 3.6e6; D.kwh += max(0.0, D.v * D.a) * dt / 3.6e9 } }
        D.last = now; D.top = max(D.top, D.spd)
    }
    private fun vesc(buf: ArrayList<Int>) {
        while (buf.size > 5) {
            val s = buf.indexOf(2); if (s < 0) { buf.clear(); return }
            if (s > 0) buf.subList(0, s).clear()
            val len = buf[1]; val tot = len + 5; if (buf.size < tot) return
            val fr = buf.subList(0, tot).map { it.toByte() }.toByteArray(); buf.subList(0, tot).clear()
            if (fr[tot - 1].toInt() != 3 || fr[2].toInt() != 4 || len < 30) continue
            val d = ByteBuffer.wrap(fr.copyOfRange(2, 2 + len))
            D.tmos = d.getShort(1) / 10.0; D.tm = d.getShort(3) / 10.0; D.a = d.getInt(9) / 100.0; D.rpm = d.getInt(25).toDouble(); D.v = d.getShort(29) / 10.0
            val pp = (sp.getString("pp", "15") ?: "15").toDoubleOrNull() ?: 15.0; val g = (sp.getString("gr", "1") ?: "1").toDoubleOrNull() ?: 1.0
            val dm = ((sp.getString("wd", "10") ?: "10").toDoubleOrNull() ?: 10.0) * 0.0254
            D.spd = abs(D.rpm) / pp / g * PI * dm * 60 / 1000; integrate()
        }
    }
    private fun daly(buf: ArrayList<Int>) {
        var s = -1; for (i in 0 until buf.size - 1) if (buf[i] == 0xAA && buf[i + 1] == 0x55) { s = i; break }
        if (s < 0) { if (buf.size > 300) buf.clear(); return }
        if (s > 0) buf.subList(0, s).clear()
        if (buf.size < 140) return
        val f = buf.subList(0, 140).toList(); buf.subList(0, 140).clear()
        fun u16(o: Int) = (f[o] shl 8) or f[o + 1]
        D.cells = (0 until 32).map { u16(6 + it * 2) * 0.001 }.filter { it > 0.5 }
        D.v = u16(4) * 0.1; D.a = u16(70) * 0.1; D.soc = f[74].toDouble(); integrate()
    }
    private fun votol(buf: ArrayList<Int>) {
        if (buf.size < 21) return
        val f = buf.takeLast(21); buf.clear()
        D.rpm = (f[5] or (f[6] shl 8)) / 10.0; D.spd = abs((f[7] or (f[8] shl 8)).toShort() / 10.0); integrate()
    }
}
